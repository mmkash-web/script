import os
from telethon import *
import datetime as DT
import requests, time, subprocess, re, sqlite3, sys, random, base64, json, math, logging

# Set the base directory to the location of this script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# Load variables from var.txt
with open(os.path.join(BASE_DIR, "var.txt"), "r") as file:
    exec(file.read())

# Initialize TelegramClient
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# Ensure the database exists
db_path = os.path.join(BASE_DIR, "database.db")
if not os.path.exists(db_path):
    x = sqlite3.connect(db_path)
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    x.commit()

def get_db():
    db_path = os.path.join(BASE_DIR, "database.db")
    x = sqlite3.connect(db_path)
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    a = [v[0] for v in x]
    return "true" if id in a else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"